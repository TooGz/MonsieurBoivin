---
title: "Côte de bœuf fumée"
date: 2025-02-12
draft: false
type: "recette"
categories: ["Recettes"]
tags: ["Barbecue","boeuf","canard", "fumage"]
rating: 5
status: "testé"
image: "img/cote-de-boeuf.jpg"
slug: "cote-de-boeuf-fumee"
---
## Ingrédients :
- 1 côte de bœuf
- Sel, poivre
- Bois de fumage (chêne, hickory)
- Huile d'olive

## Préparation :
1. Assaisonner la viande et la laisser reposer.
2. Préchauffer le Big Green Egg à 110°C en chaleur indirecte.
3. Ajouter le bois de fumage et placer la viande sur la grille.
4. Fumer jusqu’à 52°C à cœur, puis saisir rapidement à haute température.
5. Laisser reposer avant de déguster.
